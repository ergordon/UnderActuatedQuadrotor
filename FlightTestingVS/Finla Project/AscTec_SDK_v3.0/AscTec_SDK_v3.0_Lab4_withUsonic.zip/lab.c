/*
 * lab.c
 *
 *  Created on: Jan 26, 2015
 *      Author: hanley6
 */

/*----------------------------------------------------------------------*/
/*------------------------------ Preamble ------------------------------*/
/*----------------------------------------------------------------------*/

/*--------------- Includes ---------------*/
#include "lab.h"
#include "math.h"
/*------------- End Includes -------------*/

/*---------- Function Prototypes ---------*/
void lab2(void);
void lab3(void);
void Command(void);
void VelocityEst(void);
void Bens_Control_Law(void);
void Bens_Command(void);
/*-------- End Function Prototypes -------*/

/*--------------- Globals ----------------*/
struct imuSensor imusensor;
struct U u;
struct realMOCAP real_mocap;
struct MOCAP mocap;
struct GoalPosYaw goalposyaw;

/////////// HUMMINGBIRD PARAMETERS /////////////
// These below worked
//float mass = 1.7;  	// TO BE ENTERED!
//float kF = 1.607e-5; 	// TO BE ENTERED!		
//float kM = 3.2475e-7; 	// TO BE ENTERED!
//float l = 0.17;    	// TO BE ENTERED!

float mass = 0.7;  	// TO BE ENTERED!
float kF = 7.49e-6; 	// TO BE ENTERED!
float kM = 1.13e-7; 	// TO BE ENTERED!
float l = 0.17;    	// TO BE ENTERED!
		
float MAXPHI2 = 779.5638*779.5638;	// TO BE ENTERED!
float MINPHI2 = 112.705875*112.705875;	// TO BE ENTERED!
////////////////////////////////////////////

// Other Declarations
float Winv[4*4];
float cnt_u[4];
float omega_cmd2[4];
float omega_cmd[4];
float cmd[4];
float roll_desired;
float pitch_desired;
float yaw_desired;
float x_nom[4];
float g = 9.80665;	// Standard Gravity m/s^2
float z[3];		// Sensor measurement for Kalman Filter

//Benjamin Kuo Additions for Usonics
extern int USMaxBot_range1;

short Ben_thrust = 0;

	//USonic Gains
	float U_Kp_z = -40.0;
	float U_Kd_z = 2.0;//-20;
	float U_Ki_z = 0.0;

	short setpoint = 30;

int usonic_error = 0;
int usonic_error_old = 0;
short landing_flag = 0;
long clock_divider = 0;


//End Benjamin Kuo Additions
/*------------- End Globals --------------*/

/*----------------------------------------------------------------------*/
/*---------------------------- End Preamble ----------------------------*/
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/*------------------ Main Loop (called at 1 kHz) -----------------------*/
/*----------------------------------------------------------------------*/
void lab(void)
{
	// Desired Position
	x_nom[0] = goalposyaw.x;	// x/North (m)
	x_nom[1] = goalposyaw.y;	// y/East (m)
	x_nom[2] = goalposyaw.z;	// z/Down (m)
	x_nom[3] = goalposyaw.yaw;	// yaw (rad)	

	// Velocity Estimation	
	VelocityEst();

	// Lab 3
	lab3();

	// Lab 2
	//lab2();

	// Convert Controller Outputs to Motor Inputs
	Command();
	//Bens_Control_Law();
	//Bens_Command();
}
/*----------------------------------------------------------------------*/
/*---------------- End Main Loop (called at 1 kHz) ---------------------*/
/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
/*------------------------------ Helpers -------------------------------*/
/*----------------------------------------------------------------------*/
/*---------- Velocity Estimator ----------*/
int LED1toggle = 0;
int LED1count = 0;

void VelocityEst() {


	if ( (previousXMeas != real_mocap.dX) || (previousYMeas != real_mocap.dY) || (previousZMeas != real_mocap.dZ) ) {
		numCMDs = numCMDs + 1.0;
		LED1count++;
		if (0==(LED1count%10)) {
			if (LED1toggle == 0) {
				LED(1,OFF);
				LED1toggle = 1;
			} else {
				LED(1,ON);
				LED1toggle = 0;
			}
		}
 		// Velocity Estimation
		if (initialize == 0)
		{
			// Initialization
			mocap.dX = real_mocap.dX;
			mocap.dY = real_mocap.dY;
			mocap.dZ = real_mocap.dZ;
			mocap.dVx = 0.0;
			mocap.dVy = 0.0;
			mocap.dVz = 0.0;

			initialize = 1;
		}
		else
		{
		
			mocap.dVx = (real_mocap.dX - previousXMeas)/0.02;
			mocap.dVy = (real_mocap.dY - previousYMeas)/0.02;
			mocap.dVz = (real_mocap.dZ - previousZMeas)/0.02;

			// Set Position
			mocap.dX = real_mocap.dX;
			mocap.dY = real_mocap.dY;
			mocap.dZ = real_mocap.dZ;

			/*--- End Low Pass Filtering ---*/
		}
	}
	// Save Current MoCap Measurement as Previous Measurement
	previousXMeas = real_mocap.dX;
	previousYMeas = real_mocap.dY;
	previousZMeas = real_mocap.dZ;


}

/*-------- End Velocity Estimator --------*/


int LED0timeCount = 0;
int LED0toggle = 0;
/*-------------- Controller --------------*/
/*-------------- Lab 3 --------------*/
void lab3() {

	if (LED0timeCount == 250) {
		LED0timeCount = 0;
		if (LED0toggle == 0) {
			LED(0,OFF);
			LED0toggle = 1;
		} else {
			LED(0,ON);
			LED0toggle = 0;
		}
	}
	LED0timeCount++;
	
	// Error Update (for integral control)	
	if (takeoff2 == 1) {
		if (IntegralHolder == 0) {
			errorcum[0] = (x_nom[0]-mocap.dX)*0.02 + errorcum[0];
			errorcum[1] = (x_nom[1]-mocap.dY)*0.02 + errorcum[1];
			errorcum[2] = (x_nom[2]-mocap.dZ)*0.02 + errorcum[2];
		}

		IntegralHolder++;
		if (IntegralHolder == 10) {
			IntegralHolder = 0;
		}
	}


	// OUTER LOOP
		// Hummingbird
	
	float Kp_x = -0.1952;
	float Kd_x = -0.2446;
	float Ki_x = 0.0;
	float Kp_y = 0.1952;
	float Kd_y = 0.2446;
	float Ki_y = 0.0;
	float Kp_z = -10.0;//-4.3112;
	float Kd_z = -6.0;//2.4473;
	float Ki_z = 0.0;


	//short fusion_speed_x; 	//[mm/s]
	//Xspeed = (((float)RO_ALL_Data.fusion_speed_x)/1000.0);
	Xspeed = mocap.dVx;
	//short fusion_speed_y;	//[mm/s]
	//Yspeed = (((float)RO_ALL_Data.fusion_speed_y)/1000.0);
	Yspeed = mocap.dVy;
	
	// Outer Loop PD
	float a_x;
	float a_y;
	a_x = Kp_x*(x_nom[0]-mocap.dX)-Kd_x*mocap.dVx+Ki_x*errorcum[0];
	a_y = Kp_y*(x_nom[1]-mocap.dY)-Kd_y*mocap.dVy+Ki_y*errorcum[1];
	pitch_desired = a_x*cos(real_mocap.dThetaz)-a_y*sin(real_mocap.dThetaz);
	roll_desired = a_x*sin(real_mocap.dThetaz)+a_y*cos(real_mocap.dThetaz);
	yaw_desired = x_nom[3];
	cnt_u[3] = Kp_z*(x_nom[2]-mocap.dZ)-Kd_z*mocap.dVz+mass*9.81+Ki_z*errorcum[2];

	// INNER LOOP
		// Hummingbird
	float Ktx_P = 1.0;
	float Ktx_D = 0.3;
	float Kty_P = 1.0;	
	float Kty_D = 0.3;	
	float Ktz_P = 1.0;	
	float Ktz_D = 0.3;
		


	// Inner Loop PD
	cnt_u[0] = Ktx_P*(roll_desired-imusensor.dThetax)-Ktx_D*(imusensor.dOmegax);
	cnt_u[1] = Kty_P*(pitch_desired-imusensor.dThetay)-Kty_D*(imusensor.dOmegay);
		// Yaw Control with out Compass/MoCap correction
	cnt_u[2] = Ktz_P*(yaw_desired-imusensor.dThetaz)-Ktz_D*(imusensor.dOmegaz);

	// For Keeping data
	u.u1 = cnt_u[0];
	u.u2 = cnt_u[1];
	u.u3 = cnt_u[2];
	u.u4 = cnt_u[3];

	// Integral anti-windup
		// x-position anti-windup
	if (errorcum[0] > 0.875) {
		errorcum[0] = 0.875;
	}	
	else if (errorcum[0] < -0.875) {
		errorcum[0] = -0.875;
	}

		// y-position anti-windup
	if (errorcum[1] > 0.875) {
		errorcum[1] = 0.875;
	}
	else if (errorcum[1] < -0.875) {
		errorcum[1] = -0.875;
	}

		// z-position anti-windup
	if (errorcum[2] > 2.5) {
		errorcum[2] = 2.5;
	}
	else if (errorcum[2] < -2.5) {
		errorcum[2] = -2.5;
	}
}	
/*------------ End Lab 3 ------------*/

/*-------------- Lab 2 --------------*/
void lab2() {
	
	// Desired	
	pitch_desired = 0.0;
	
	// INNER LOOP
		// Hummingbird
//	float Ktx_P = 1.0;	// Proportional Roll
//	float Ktx_D = 0.3;	// Derivative Roll
	float Kty_P = 1.0;	// Proportional Pitch
	float Kty_D = 0.3;	// Derivative Pitch
//	float Ktz_P = 0.08;	// Proportional Yaw
//	float Ktz_D = 0.04;	// Derivative Yaw
		
	// Inner Loop PD 
	// Note: Lab 2 only tests Pitch control. Do not uncomment roll and yaw lines.
	cnt_u[0] = 0.0; // Ktx_P*(roll_desired-imusensor.dThetax)-Ktx_D*(imusensor.dOmegax);
	cnt_u[1] = Kty_P*(pitch_desired-imusensor.dThetay)-Kty_D*(imusensor.dOmegay);
	cnt_u[2] = 0.0;//Ktz_P*(yaw_desired-imusensor.dThetaz)-Ktz_D*(imusensor.dOmegaz);

	// For Keeping data
	u.u1 = cnt_u[0];
	u.u2 = cnt_u[1];
	u.u3 = cnt_u[2];
	u.u4 = cnt_u[3];
}
/*------------ End Lab 2 ------------*/
/*------------ End Controller ------------*/

/*---------------- Command ---------------*/
void Command() {
	/////////////// Controller Settings ////////////
	WO_SDK.ctrl_mode=0x00;  //0x00: direct individual motor control (individual commands for motors 0...3)
				//0x01: direct motor control using standard output mapping: commands are interpreted as pitch, roll, yaw 
				//      and thrust inputs; no attitude controller active
				//0x02: attitude and throttle control: commands are input for standard attitude controller
				//0x03: GPS waypoint control

	WO_SDK.ctrl_enabled=1;	//0: disable control by HL processor
				//1: enable control by HL processor
	////////////////////////////////////////////////

	//////// Translate commanded torques and thrust into rotor speed and commands ////////////
	// NOTE METHOD BELOW ASSUMES THAT CG IS IN THE SAME PLANE AS THE ROTORS
	float twolkF = 1.0/(2.0*l*kF);
	float fourkF = 1.0/(4.0*kF);
	float fourkM = 1.0/(4.0*kM);

	Winv[0] = 0;
	Winv[1] = twolkF;
	Winv[2] = -fourkM;
	Winv[3] = fourkF;
	Winv[1*4+0] = -twolkF;
	Winv[1*4+1] = 0;
	Winv[1*4+2] = fourkM;
	Winv[1*4+3] = fourkF;
	Winv[2*4+0] = 0;
	Winv[2*4+1] = -twolkF;
	Winv[2*4+2] = -fourkM;
	Winv[2*4+3] = fourkF;
	Winv[3*4+0] = twolkF;
	Winv[3*4+1] = 0;
	Winv[3*4+2] = fourkM;
	Winv[3*4+3] = fourkF;

	matrix_multiply(4,4,1,Winv,cnt_u,omega_cmd2);

	int i;
	for (i=0; i<4; i++) {
		if (omega_cmd2[i] > MAXPHI2) {
			omega_cmd2[i] = MAXPHI2;
		}
		else if (omega_cmd2[i] < MINPHI2) {
			omega_cmd2[i] = MINPHI2;
		}
		omega_cmd[i] = sqrt(omega_cmd2[i]);
		// Translate Desired Rotor Speed into Motor Commands
		// NOTE: THIS IS FOR THE PELICAN
		cmd[i] = 0.238432*omega_cmd[i] - 25.872642;	// Verify

		// Below is a safety measure. We want to make sure the motor 
		// commands are never 0 so that the motors will always keep 
		// spinning. Also makes sure that motor commands stay within range.
		// NOTE: THIS SHOULD BE UNNECESSARY. I IMPLEMENTED THIS AS AN EXTRA 
		// SAFETY MEASURE
		if (cmd[i] < 1.0) {
			cmd[i] = 1.0;
		}
		else if (cmd[i] > 200.0) {
			cmd[i] = 200.0;
		} 
	}
	/////////////////////////////////////////////////////////////////////////////////////////////

	/////// Send Motor Commands ///////////
	WO_Direct_Individual_Motor_Control.motor[0] = cmd[0];
	WO_Direct_Individual_Motor_Control.motor[3] = cmd[1];
	WO_Direct_Individual_Motor_Control.motor[1] = cmd[2];
	WO_Direct_Individual_Motor_Control.motor[2] = cmd[3];
	///////////////////////////////////////
}
/*-------------- End Command -------------*/

/*----------------Ben's Control Law ---------------*/
void Bens_Control_Law(void) {
	int Usonic_local = 10;

	if (USMaxBot_range1 > 70)
		Usonic_local = 70;
	else if(USMaxBot_range1 < 7)
		Usonic_local = 7;
	else
		Usonic_local = USMaxBot_range1;

	usonic_error =(Usonic_local-setpoint);

	if (Usonic_local <= 7)
	{
		// if ((clock_divider % 5) == 0)
		// {
			Ben_thrust--;
		// }
	}
	else
	{
		if(landing_flag == 1)
		{
		if (((clock_divider % 50) == 0) && (setpoint > 6))
			{
				setpoint--;
				if (setpoint <= 6)
				{
					setpoint = 7;
				}
			}
		}
		Ben_thrust = U_Kp_z*usonic_error-U_Kd_z*RO_ALL_Data.fusion_dheight+1700;
	}

	// if (clock_divider == 30000)
	// {
	// 	landing_flag = 1;
	// }

	setpoint = RO_RC_Data.channel[6]/133;

	// if (RO_RC_Data.channel[6] < 1000)
	// 	landing_flag = 0;
	// else
	// 	landing_flag = 1;

	if(Ben_thrust < 10)
		Ben_thrust = 10;

	usonic_error_old = usonic_error;
	clock_divider++;
}
/*-------------- End Ben's Command -------------*/

/*----------------Ben's Command ---------------*/
void Bens_Command(void) {
	/////////////// Controller Settings ////////////
	WO_SDK.ctrl_mode=0x02;  //0x00: direct individual motor control (individual commands for motors 0...3)
				//0x01: direct motor control using standard output mapping: commands are interpreted as pitch, roll, yaw
				//      and thrust inputs; no attitude controller active
				//0x02: attitude and throttle control: commands are input for standard attitude controller
				//0x03: GPS waypoint control

	WO_SDK.ctrl_enabled=1;	//0: disable control by HL processor
				//1: enable control by HL processor


	//We're no longer using Direct Motor Commands because Asctec's own attitude controller is better.
	WO_CTRL_Input.ctrl=0x08;	//0x08: enable throttle control by HL. Height control and GPS are deactivated!!
								//pitch, roll and yaw are still commanded via the remote control
	//WO_CTRL_Input.thrust=400;	//10% throttle command
	WO_CTRL_Input.thrust=(short) Ben_thrust;	//Proportional throttle command

	//
	//Note to self, We'll start testing around the thrust value of 1700
	//This was done by inspection from Dan Block and Ben Kuo
	//
}
/*-------------- End Ben's Command -------------*/
/*----------------------------------------------------------------------*/
/*---------------------------- End Helpers -----------------------------*/
/*----------------------------------------------------------------------*/

